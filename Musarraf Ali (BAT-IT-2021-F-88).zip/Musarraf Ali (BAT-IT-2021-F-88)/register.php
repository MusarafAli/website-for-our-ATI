<?php
session_start();

// Include the database connection script
include 'db.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $designation = $_POST['designation'];
    $courseID = $_POST['course'];
    $gender = $_POST['gender'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    
    $sql = "INSERT INTO Lecturer (Name, Email, Designation, CourseID, Gender, Password) 
            VALUES ('$name', '$email', '$designation', $courseID, '$gender', '$password')";

    if ($conn->query($sql) === TRUE) {
        // Registration successful, redirect to login page
        header("Location: login.php");
        exit();
    } else {
        // Handle registration error
        $error_message = "Error: " . $conn->error;
    }

    $conn->close();
}
?>


<html>
<head>
<title>Lecturer Registration</title>
<style>
      
      body{
            display :flex;
            justify-content:center;
            align-items:center;
            background:url('ati.jpg') no-repeat;
            background-size:cover;
            background-position:center;
        
            }
        .Registration-box{
            position: relative;
            width: 500px;
            height: 750px;
            background:white;
           
            border-radius:50px 5px;
            display:flex;
            justify-contennt:center;
            align-items:center;
            overflow:hidden;
        }
        .Registration-box::before{
            content:'';
            position:absolute;
            top:-50%;
            left:-50%;
            width:450px;
            height:600px;
            background:linear-gradient(60deg,transparent,#45f3ff,#45f3ff);
            transform-origin:bottom right;
            animation:animate 6s linear infinite;
        }
        .Registration-box::after{
            content:'';
            position:absolute;
            top:-50%;
            left:-50%;
            width:450px;
            height:600px;
            background:linear-gradient(60deg,transparent,#d9138a,#d9138a);
            transform-origin:bottom right;
            animation:animate 6s linear infinite;
            animation-delay:-3s;
        }
        @keyframes animate{
            0%{
                transform:rotate(0deg);
            }
            10%{
                transform:rotate(360deg);
            }
        }
        form{
            position:absolute;
            inset:10px;
            border-radius:50px 10px;
            background:white;
            z-index:10;
            pading:30px 30px;
            display:flex;
            flex-direction:column;
        }
        
        
        h1{
            color:black;
            font-size:35px;
            font-weight:500;
            text-align:center;
        }
.inputbox{
    position:relative;
    width:300px;
    color:gray;
    margin-top:20px;
}
.inputbox input{
    position:relative;
    width:100%;
    padding:20px 10px 10px;
    background:skyblue;
    border:none;
    outline:none;
    font-size:1em;
    letter-spacing:0.05em;
    z-index:10;
}
.inputbox select{
    position:relative;
    width:100%;
    padding:20px 10px 10px;
    background:skyblue;
    border:none;
    outline:none;
    font-size:1em;
    letter-spacing:0.05em;
    z-index:10;
}
input[type="submit"]{
    font-size:20px;
    border:none;
    outline:none;
    background:skyblue;
    padding:5px;
    margin-top:40px;
    border-radius:90px;
    font-weight:600;
    width: 250px;
    cursor:pointer;
}
input[type="submit"]:active
{
    background:linear-gradient(90deg,transparent,#45f3ff,#d9138a);
    opacity: 0.8;
}
.register{
    text-align:center; 
}
.center{
    
    padding:95px;
    margin-top:-100;
 
 } 
 
        </style>
</head>
<body>
<div class="Registration-box">

   
    
    <?php if (isset($error_message)) { ?>
        <p style="color: red;"><?php echo $error_message; ?></p>
    <?php } ?>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <div class="center">
    <h1>Lecturer Registration</h1>
   
    <div class="inputbox">

    <label for="name" >Name in full:</label>
    <input type="text" name="name" required placeholder="Ender Full Name">
    </div>
    <div class="inputbox">
    <label for="email" >Email:</label>
    <input type="email" name="email" required placeholder="Ender Email">
    </div>
    <div class="inputbox">
    <label for="designation">Designation:</label><br>
    <select name="designation" required>
            <option value="Assistant Lecturer">Assistant Lecturer</option>
            <option value="Senior Lecturer 1">Senior Lecturer 1</option>
            <option value="Senior Lecturer 2">Senior Lecturer 2</option>
        </select>
    </div>
    <div class="inputbox">
    <label for="course">Course:</label><br>
    <select name="course" required>
            <!-- Fetch course list from the Course table and populate the dropdown -->
            <?php
            $course_query = "SELECT * FROM Course";
            $result = $conn->query($course_query);
            while ($row = $result->fetch_assoc()) {
                echo "<option value='{$row['CourseID']}'>{$row['Title']}</option>";
            }
            ?>
        </select>
    </div>
    <div class="inputbox">
    <label for="gender">Gender:</label><br>
    <select name="gender" required>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
        </select>
    </div>
    <div class="inputbox">
    <label for="password" >Password:</label>
    <input type="password" name="password" required placeholder="Ender Password">
    </div>
    
     <div class="register"> <input type="submit" value="Register"> </div>
     </div> 
    </form>
        </div>
       
</body>
</html>
